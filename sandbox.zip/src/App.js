import "./App.css";
import React, { useState, useEffect } from "react";
import SearchIcon from "./Search.svg";
import MovieCard from "./MovieCard";

const API_URL = " http://www.omdbapi.com?apikey=4bdf5039";
function App() {
  const [Movies, setMovies] = useState([]);
  const [searchterm, setSearchTerm] = useState("");

  const SearchMovie = async (title) => {
    const response = await fetch(`${API_URL}&s=${title}`);
    const Data = await response.json();
    setMovies(Data.search);
  };

  useEffect(() => {
    SearchMovie("Spiderman");
  }, []);

  return (
    <div className="app">
      <h1>MovieWorld</h1>
      <div className="search">
        <input
          value={searchterm}
          onClick={(e) => setSearchTerm(e.target.value)}
          placeholder="Search Movies"
        />
        <img
          src={SearchIcon}
          onClick={() => SearchMovie(searchterm)}
          alt="search"
        />
      </div>

      {Movies?.length > 0 ? (
        <div className="container">
          {Movies.map((movie) => (
            <MovieCard movie={movie} />
          ))}
        </div>
      ) : (
        <div className="empty">
          <h2>No movies found</h2>
        </div>
      )}
    </div>
  );
}
export default App;
